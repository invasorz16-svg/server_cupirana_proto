#!/usr/bin/env python3
"""
VMC Control Center — Aplicación de Escritorio
Controla tu máquina expendedora sin abrir el navegador.
Requiere Python 3.8+ (incluye Tkinter por defecto)
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
import urllib.request
import urllib.error
import json
import time
from datetime import datetime

# ══════════════════════════════════════════════
#  CONFIGURACIÓN
# ══════════════════════════════════════════════
API  = "https://api.vmc002.csmology.com"
RSA_PUBLIC_KEY = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAN378k3RiZHWx5AfJqdH9xRNBmD9wGD\n2iRe41HdTNF8RUhNnHit5NpMNtGL0NPTSSPpjjI1kJfVorRvaQerUgkCAwEAAQ=="

# Token pre-cargado (se reemplaza al hacer login)
SAVED_TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJ1aWQiOiJkYzk1ZDY1YTkxMmM0OWNhODcxMDYzNDIxYWJmMGYzMCIsInVzZXJJZCI6MjUyLCJzdWIiOiJkYW5pZWxfMjg5NkBob3RtYWlsLmNvbSJ9.-q3Tl4yrNjyn0JvZ3L838e2jgaLeb1PKK_-lobwhDlpDEBRXhFqwRV0McIII2meAkgnT4xQrdErXn9eEQrtE7w"

# Colores
BG      = "#0c0e12"
S1      = "#13161c"
S2      = "#1a1e26"
S3      = "#232834"
BORDER  = "#2d3344"
ACCENT  = "#4ade80"
BLUE    = "#60a5fa"
RED     = "#f87171"
ORANGE  = "#fb923c"
YELLOW  = "#fbbf24"
TEXT    = "#d1d5db"
BRIGHT  = "#f9fafb"
MUTED   = "#6b7280"

CMDS = {
    "0100": ("Normal Service",   "✅", False),
    "0101": ("Out of Service",   "🚫", True),
    "0301": ("Shutdown",         "⏻",  True),
    "0302": ("Reboot",           "🔄", True),
    "0307": ("Restart Software", "🔁", False),
    "0401": ("Upgrade",          "⬆️", True),
}

# ══════════════════════════════════════════════
#  API
# ══════════════════════════════════════════════
class VMCApi:
    def __init__(self):
        self.token = SAVED_TOKEN

    def request(self, method, path, body=None):
        url = API + path
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", self.token)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            try:
                return json.loads(e.read().decode())
            except:
                return {"error": str(e)}
        except Exception as e:
            return {"error": str(e)}

    def get_stats(self):
        return self.request("POST", "/api/statistics/getSaleCount", {})

    def get_machines(self):
        return self.request("GET", "/api/terminal?sort=createDate%2Cdesc&page=0&size=100")

    def get_orders(self):
        return self.request("GET", "/api/commodityOrder?page=0&size=100&sort=createDate%2Cdesc")

    def get_products(self):
        return self.request("GET", "/api/goods?page=0&size=200")

    def get_replenishment(self):
        return self.request("GET", "/api/replenishmentOperations?page=0&size=100&sort=createDate%2Cdesc")

    def get_machine_status(self, terminal_code):
        return self.request("GET", f"/api/devCompStatus?terminalCode={terminal_code}&page=0&size=50")

    def send_command(self, terminal_code, control):
        return self.request("POST", "/api/devCommand", {
            "terminalCode": terminal_code,
            "control": control
        })

    def login(self, username, password_encrypted, code, uuid):
        return self.request("POST", "/auth/login", {
            "username": username,
            "password": password_encrypted,
            "code": code,
            "uuid": uuid
        })

    def get_captcha(self):
        return self.request("GET", "/auth/code")

# ══════════════════════════════════════════════
#  APLICACIÓN PRINCIPAL
# ══════════════════════════════════════════════
class VMCApp:
    def __init__(self, root):
        self.root = root
        self.api = VMCApi()
        self.selected_machine = None
        self.machines_data = []
        self.orders_data = []
        self.products_data = []
        self.rep_data = []
        self.auto_refresh = True
        self.refresh_interval = 60  # segundos

        self.setup_window()
        self.build_ui()
        self.start_auto_refresh()
        self.refresh_all()

    def setup_window(self):
        self.root.title("VMC Control Center")
        self.root.geometry("1100x700")
        self.root.minsize(900, 600)
        self.root.configure(bg=BG)
        # Ícono (sin archivo externo)
        try:
            self.root.iconbitmap(default="")
        except:
            pass

    def build_ui(self):
        # ── TOP BAR ──
        topbar = tk.Frame(self.root, bg=S1, height=50)
        topbar.pack(fill="x", side="top")
        topbar.pack_propagate(False)

        tk.Label(topbar, text="VMC·Control", bg=S1, fg=ACCENT,
                 font=("Consolas", 14, "bold")).pack(side="left", padx=16, pady=10)

        self.conn_label = tk.Label(topbar, text="● Conectando...", bg=S1, fg=MUTED, font=("Segoe UI", 10))
        self.conn_label.pack(side="right", padx=16)

        self.last_update_label = tk.Label(topbar, text="", bg=S1, fg=MUTED, font=("Segoe UI", 9))
        self.last_update_label.pack(side="right", padx=8)

        tk.Button(topbar, text="⟳ Actualizar", bg=S3, fg=TEXT,
                  font=("Segoe UI", 9), relief="flat", cursor="hand2",
                  command=lambda: threading.Thread(target=self.refresh_all, daemon=True).start()
                  ).pack(side="right", padx=4, pady=10)

        # ── NOTEBOOK (tabs) ──
        style = ttk.Style()
        style.theme_use("default")
        style.configure("VMC.TNotebook", background=S1, borderwidth=0)
        style.configure("VMC.TNotebook.Tab", background=S2, foreground=MUTED,
                        font=("Segoe UI", 10), padding=[14, 8])
        style.map("VMC.TNotebook.Tab",
                  background=[("selected", BG)],
                  foreground=[("selected", ACCENT)])

        self.nb = ttk.Notebook(self.root, style="VMC.TNotebook")
        self.nb.pack(fill="both", expand=True)

        # Tabs
        self.tab_dash   = self.make_frame()
        self.tab_mach   = self.make_frame()
        self.tab_ctrl   = self.make_frame()
        self.tab_orders = self.make_frame()
        self.tab_prod   = self.make_frame()
        self.tab_rep    = self.make_frame()
        self.tab_log    = self.make_frame()

        self.nb.add(self.tab_dash,   text="📊 Dashboard")
        self.nb.add(self.tab_mach,   text="🏪 Máquinas")
        self.nb.add(self.tab_ctrl,   text="🎮 Control")
        self.nb.add(self.tab_orders, text="🧾 Pedidos")
        self.nb.add(self.tab_prod,   text="📦 Productos")
        self.nb.add(self.tab_rep,    text="🔄 Reabast.")
        self.nb.add(self.tab_log,    text="📋 Log")

        self.build_dashboard()
        self.build_machines()
        self.build_control()
        self.build_orders()
        self.build_products()
        self.build_replenishment()
        self.build_log()

    def make_frame(self):
        f = tk.Frame(self.nb, bg=BG)
        return f

    # ── DASHBOARD ──────────────────────────────
    def build_dashboard(self):
        f = self.tab_dash
        pad = {"padx": 16, "pady": 8}

        # Stats cards
        cards_frame = tk.Frame(f, bg=BG)
        cards_frame.pack(fill="x", **pad)

        self.stat_vars = {}
        stats = [
            ("💰 Ingresos hoy",    "rev_day",   ACCENT),
            ("🛒 Ventas hoy",      "count_day",  BLUE),
            ("📅 Ventas mes",      "count_month",BRIGHT),
            ("💵 Monto mes",       "rev_month",  YELLOW),
            ("🏪 Máquinas online", "machines_on",ORANGE),
        ]
        for i, (label, key, color) in enumerate(stats):
            card = tk.Frame(cards_frame, bg=S1, relief="flat", bd=0)
            card.grid(row=0, column=i, padx=6, pady=4, sticky="nsew")
            cards_frame.columnconfigure(i, weight=1)

            var = tk.StringVar(value="—")
            self.stat_vars[key] = var
            tk.Label(card, textvariable=var, bg=S1, fg=color,
                     font=("Consolas", 22, "bold")).pack(pady=(12,2), padx=14)
            tk.Label(card, text=label, bg=S1, fg=MUTED,
                     font=("Segoe UI", 9)).pack(pady=(0,12), padx=14)

        # Últimas ventas
        lbl_frame = tk.Frame(f, bg=BG)
        lbl_frame.pack(fill="x", padx=16, pady=(8,4))
        tk.Label(lbl_frame, text="ÚLTIMAS VENTAS", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(side="left")

        cols = ("Folio", "Producto", "Máquina", "Monto", "Fecha", "Estado")
        self.dash_tree = self.make_tree(f, cols)

    # ── MÁQUINAS ───────────────────────────────
    def build_machines(self):
        f = self.tab_mach
        toolbar = tk.Frame(f, bg=BG)
        toolbar.pack(fill="x", padx=16, pady=8)
        self.mach_count_var = tk.StringVar(value="—")
        tk.Label(toolbar, textvariable=self.mach_count_var, bg=BG, fg=MUTED,
                 font=("Segoe UI", 10)).pack(side="left")
        tk.Button(toolbar, text="⟳ Actualizar", bg=S3, fg=TEXT, font=("Segoe UI", 9),
                  relief="flat", cursor="hand2",
                  command=lambda: threading.Thread(target=self.load_machines, daemon=True).start()
                  ).pack(side="right")

        cols = ("SN / Código", "Nombre", "Estado", "IP Interna", "IP Externa", "SW Ver.", "Modelo", "Última sync")
        self.mach_tree = self.make_tree(f, cols)
        self.mach_tree.bind("<<TreeviewSelect>>", self.on_machine_select)

        tk.Label(f, text="↑ Haz doble clic o selecciona para ir a Control", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9)).pack(pady=4)
        self.mach_tree.bind("<Double-1>", lambda e: self.nb.select(self.tab_ctrl))

    # ── CONTROL ────────────────────────────────
    def build_control(self):
        f = self.tab_ctrl

        # Info máquina seleccionada
        info_frame = tk.Frame(f, bg=S1)
        info_frame.pack(fill="x", padx=16, pady=(12,4))

        tk.Label(info_frame, text="🏪", bg=S1, font=("Segoe UI", 20)).pack(side="left", padx=12, pady=10)
        name_frame = tk.Frame(info_frame, bg=S1)
        name_frame.pack(side="left", pady=10)
        self.ctrl_name_var = tk.StringVar(value="Selecciona una máquina en 'Máquinas'")
        self.ctrl_meta_var = tk.StringVar(value="")
        tk.Label(name_frame, textvariable=self.ctrl_name_var, bg=S1, fg=BRIGHT,
                 font=("Segoe UI", 13, "bold")).pack(anchor="w")
        tk.Label(name_frame, textvariable=self.ctrl_meta_var, bg=S1, fg=MUTED,
                 font=("Segoe UI", 10)).pack(anchor="w")
        self.ctrl_status_var = tk.StringVar(value="")
        tk.Label(info_frame, textvariable=self.ctrl_status_var, bg=S1,
                 font=("Segoe UI", 10, "bold")).pack(side="right", padx=12)

        # IP/SW info
        ip_frame = tk.Frame(f, bg=S2)
        ip_frame.pack(fill="x", padx=16, pady=4)
        self.ctrl_ip1 = tk.StringVar(value="—")
        self.ctrl_ip2 = tk.StringVar(value="—")
        self.ctrl_ver = tk.StringVar(value="—")
        self.ctrl_sync = tk.StringVar(value="—")
        for i, (lbl, var) in enumerate([("IP Interna",self.ctrl_ip1),("IP Externa",self.ctrl_ip2),("SW Ver.",self.ctrl_ver),("Última sync",self.ctrl_sync)]):
            col = tk.Frame(ip_frame, bg=S2)
            col.grid(row=0, column=i, padx=12, pady=8, sticky="w")
            ip_frame.columnconfigure(i, weight=1)
            tk.Label(col, text=lbl.upper(), bg=S2, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w")
            tk.Label(col, textvariable=var, bg=S2, fg=BRIGHT, font=("Consolas", 11, "bold")).pack(anchor="w")

        # Botones de comandos
        main_pane = tk.Frame(f, bg=BG)
        main_pane.pack(fill="both", expand=True, padx=16, pady=8)

        left_pane = tk.Frame(main_pane, bg=BG)
        left_pane.pack(side="left", fill="both", expand=True)
        right_pane = tk.Frame(main_pane, bg=S1, width=260)
        right_pane.pack(side="right", fill="y", padx=(12,0))
        right_pane.pack_propagate(False)

        tk.Label(left_pane, text="🔄 CONTROL DE SERVICIO", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0,6))
        svc_frame = tk.Frame(left_pane, bg=BG)
        svc_frame.pack(fill="x", pady=(0,12))
        for ctrl, (label, icon, dangerous) in [("0100", CMDS["0100"]), ("0101", CMDS["0101"])]:
            color = ACCENT if not dangerous else ORANGE
            tk.Button(svc_frame, text=f"{icon}  {label}", bg=S2, fg=color,
                      font=("Segoe UI", 10), relief="flat", cursor="hand2", pady=10,
                      command=lambda c=ctrl, l=label, d=dangerous: self.send_cmd(c, l, d)
                      ).pack(side="left", fill="x", expand=True, padx=4)

        tk.Label(left_pane, text="⚙️ SISTEMA", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0,6))
        sys_frame = tk.Frame(left_pane, bg=BG)
        sys_frame.pack(fill="x", pady=(0,12))
        sys_frame2 = tk.Frame(left_pane, bg=BG)
        sys_frame2.pack(fill="x")
        row1 = [("0302", CMDS["0302"]), ("0301", CMDS["0301"])]
        row2 = [("0307", CMDS["0307"]), ("0401", CMDS["0401"])]
        for ctrl, (label, icon, dangerous) in row1:
            color = RED if dangerous else TEXT
            tk.Button(sys_frame, text=f"{icon}  {label}", bg=S2, fg=color,
                      font=("Segoe UI", 10), relief="flat", cursor="hand2", pady=10,
                      command=lambda c=ctrl, l=label, d=dangerous: self.send_cmd(c, l, d)
                      ).pack(side="left", fill="x", expand=True, padx=4)
        for ctrl, (label, icon, dangerous) in row2:
            color = RED if dangerous else BLUE
            tk.Button(sys_frame2, text=f"{icon}  {label}", bg=S2, fg=color,
                      font=("Segoe UI", 10), relief="flat", cursor="hand2", pady=10,
                      command=lambda c=ctrl, l=label, d=dangerous: self.send_cmd(c, l, d)
                      ).pack(side="left", fill="x", expand=True, padx=4, pady=(8,0))

        # Panel derecho: estado componentes
        tk.Label(right_pane, text="📡 ESTADO", bg=S1, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=12, pady=(12,6))
        tk.Button(right_pane, text="⟳ Actualizar estado", bg=S3, fg=TEXT,
                  font=("Segoe UI", 9), relief="flat", cursor="hand2",
                  command=lambda: threading.Thread(target=self.load_machine_status, daemon=True).start()
                  ).pack(fill="x", padx=12, pady=(0,8))
        self.status_text = scrolledtext.ScrolledText(right_pane, bg=S2, fg=TEXT,
            font=("Consolas", 9), relief="flat", height=20, state="disabled")
        self.status_text.pack(fill="both", expand=True, padx=8, pady=(0,8))

    # ── PEDIDOS ────────────────────────────────
    def build_orders(self):
        f = self.tab_orders
        tb = tk.Frame(f, bg=BG)
        tb.pack(fill="x", padx=16, pady=8)
        self.orders_count_var = tk.StringVar(value="—")
        tk.Label(tb, textvariable=self.orders_count_var, bg=BG, fg=MUTED, font=("Segoe UI",10)).pack(side="left")
        tk.Button(tb, text="⟳", bg=S3, fg=TEXT, font=("Segoe UI",9), relief="flat", cursor="hand2",
                  command=lambda: threading.Thread(target=self.load_orders, daemon=True).start()
                  ).pack(side="right")
        cols = ("Folio", "Producto", "Categoría", "Máquina", "Monto", "Fecha", "Estado")
        self.orders_tree = self.make_tree(f, cols)

    # ── PRODUCTOS ──────────────────────────────
    def build_products(self):
        f = self.tab_prod
        tb = tk.Frame(f, bg=BG)
        tb.pack(fill="x", padx=16, pady=8)
        self.prod_count_var = tk.StringVar(value="—")
        tk.Label(tb, textvariable=self.prod_count_var, bg=BG, fg=MUTED, font=("Segoe UI",10)).pack(side="left")
        tk.Button(tb, text="⟳", bg=S3, fg=TEXT, font=("Segoe UI",9), relief="flat", cursor="hand2",
                  command=lambda: threading.Thread(target=self.load_products, daemon=True).start()
                  ).pack(side="right")
        cols = ("ID", "Nombre", "Precio", "Tipo", "Stock", "Estado")
        self.prod_tree = self.make_tree(f, cols)

    # ── REABASTECIMIENTO ───────────────────────
    def build_replenishment(self):
        f = self.tab_rep
        tb = tk.Frame(f, bg=BG)
        tb.pack(fill="x", padx=16, pady=8)
        self.rep_count_var = tk.StringVar(value="—")
        tk.Label(tb, textvariable=self.rep_count_var, bg=BG, fg=MUTED, font=("Segoe UI",10)).pack(side="left")
        tk.Button(tb, text="⟳", bg=S3, fg=TEXT, font=("Segoe UI",9), relief="flat", cursor="hand2",
                  command=lambda: threading.Thread(target=self.load_replenishment, daemon=True).start()
                  ).pack(side="right")
        cols = ("Fecha", "Máquina", "Producto", "Cantidad", "Operador")
        self.rep_tree = self.make_tree(f, cols)

    # ── LOG ────────────────────────────────────
    def build_log(self):
        f = self.tab_log
        tb = tk.Frame(f, bg=BG)
        tb.pack(fill="x", padx=16, pady=8)
        tk.Label(tb, text="Registro de actividad", bg=BG, fg=BRIGHT,
                 font=("Segoe UI", 11, "bold")).pack(side="left")
        tk.Button(tb, text="🗑 Limpiar", bg=S3, fg=TEXT, font=("Segoe UI",9), relief="flat", cursor="hand2",
                  command=self.clear_log).pack(side="right")
        self.log_text = scrolledtext.ScrolledText(f, bg=S1, fg=TEXT, font=("Consolas", 10),
                                                   relief="flat", state="disabled")
        self.log_text.pack(fill="both", expand=True, padx=16, pady=(0,12))
        self.log_text.tag_configure("ok",   foreground=ACCENT)
        self.log_text.tag_configure("er",   foreground=RED)
        self.log_text.tag_configure("in",   foreground=BLUE)
        self.log_text.tag_configure("wr",   foreground=ORANGE)
        self.log_text.tag_configure("ts",   foreground="#c084fc")

    # ── TREEVIEW helper ────────────────────────
    def make_tree(self, parent, cols):
        style = ttk.Style()
        style.configure("VMC.Treeview", background=S1, foreground=TEXT,
                        fieldbackground=S1, rowheight=28, font=("Segoe UI", 10),
                        borderwidth=0)
        style.configure("VMC.Treeview.Heading", background=S2, foreground=MUTED,
                        font=("Segoe UI", 9, "bold"), relief="flat")
        style.map("VMC.Treeview", background=[("selected", S3)], foreground=[("selected", BRIGHT)])

        frame = tk.Frame(parent, bg=BG)
        frame.pack(fill="both", expand=True, padx=16, pady=(0,12))

        tree = ttk.Treeview(frame, columns=cols, show="headings", style="VMC.Treeview")
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        for col in cols:
            tree.heading(col, text=col)
            tree.column(col, width=120, minwidth=80)

        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        return tree

    # ══════════════════════════════════════════
    #  CARGA DE DATOS
    # ══════════════════════════════════════════
    def refresh_all(self):
        self.log("Actualizando todos los datos...", "in")
        threads = [
            threading.Thread(target=self.load_stats, daemon=True),
            threading.Thread(target=self.load_machines, daemon=True),
            threading.Thread(target=self.load_orders, daemon=True),
            threading.Thread(target=self.load_products, daemon=True),
            threading.Thread(target=self.load_replenishment, daemon=True),
        ]
        for t in threads:
            t.start()
        self.root.after(0, lambda: self.last_update_label.config(
            text="Última sync: " + datetime.now().strftime("%H:%M:%S")))

    def load_stats(self):
        d = self.api.get_stats()
        if not d or "error" in d:
            self.root.after(0, lambda: self.set_conn(False))
            return
        self.root.after(0, lambda: self.set_conn(True))
        sc = d.get("data", d)
        self.root.after(0, lambda: self._apply_stats(sc))

    def _apply_stats(self, sc):
        self.stat_vars["rev_day"].set("$" + str(int(float(sc.get("amountDay", 0)))))
        self.stat_vars["count_day"].set(str(sc.get("icountDay", 0)))
        self.stat_vars["count_month"].set(str(sc.get("icountThisMonth", 0)))
        self.stat_vars["rev_month"].set("$" + str(int(float(sc.get("amountThisMonth", 0)))))
        online = len([m for m in self.machines_data if m.get("status") in (True, 1)])
        self.stat_vars["machines_on"].set(str(online) if self.machines_data else "—")
        self.log(f"Stats: hoy={sc.get('icountDay',0)} mes={sc.get('icountThisMonth',0)} ${sc.get('amountThisMonth',0)}", "ok")

    def load_machines(self):
        d = self.api.get_machines()
        if not d or "error" in d:
            self.log("Error cargando máquinas: " + str(d), "er")
            return
        list_ = d.get("content") or d.get("list") or []
        self.machines_data = list_
        self.root.after(0, lambda: self._render_machines(list_))

    def _render_machines(self, list_):
        self.mach_tree.delete(*self.mach_tree.get_children())
        online = 0
        for m in list_:
            ts = m.get("terminalStatus") or {}
            on = m.get("status") in (True, 1)
            if on: online += 1
            status = "● Online" if on else "● Offline"
            self.mach_tree.insert("", "end", iid=m.get("code",""), values=(
                m.get("code","—"),
                m.get("name","—"),
                status,
                ts.get("intranetIp","—"),
                ts.get("internetIp","—"),
                ts.get("curVersion","—"),
                m.get("terminalModelCode","—"),
                (ts.get("lastUpdateTime","—") or "—")[:16],
            ), tags=("online" if on else "offline",))
        self.mach_tree.tag_configure("online",  foreground=ACCENT)
        self.mach_tree.tag_configure("offline", foreground=RED)
        self.mach_count_var.set(f"{len(list_)} máquinas · {online} online")
        self.stat_vars["machines_on"].set(str(online))
        self.log(f"{len(list_)} máquinas ({online} online)", "ok")

    def on_machine_select(self, event):
        sel = self.mach_tree.selection()
        if not sel: return
        code = sel[0]
        m = next((x for x in self.machines_data if x.get("code") == code), None)
        if not m: return
        self.selected_machine = m
        ts = m.get("terminalStatus") or {}
        on = m.get("status") in (True, 1)
        self.ctrl_name_var.set(m.get("name") or m.get("code") or "—")
        self.ctrl_meta_var.set(f"SN: {m.get('code','—')} · {m.get('terminalModelCode','—')}")
        self.ctrl_status_var.set("● Online" if on else "● Offline")
        self.ctrl_ip1.set(ts.get("intranetIp","—"))
        self.ctrl_ip2.set(ts.get("internetIp","—"))
        self.ctrl_ver.set(ts.get("curVersion","—"))
        self.ctrl_sync.set((ts.get("lastUpdateTime","—") or "—")[:16])
        self.log(f"Máquina seleccionada: {m.get('name') or m.get('code')}", "in")
        threading.Thread(target=self.load_machine_status, daemon=True).start()

    def load_machine_status(self):
        if not self.selected_machine: return
        code = self.selected_machine.get("code","")
        d = self.api.get_machine_status(code)
        list_ = d.get("content") or d.get("list") or [] if d else []
        self.root.after(0, lambda: self._render_status(list_))

    def _render_status(self, list_):
        self.status_text.config(state="normal")
        self.status_text.delete("1.0", "end")
        m = self.selected_machine or {}
        ts = m.get("terminalStatus") or {}
        if list_:
            for c in list_[:15]:
                ok = c.get("status") in (1, True, "normal")
                name = c.get("compType") or c.get("name","—")
                status = "✓ OK" if ok else "✗ Error"
                color = "ok" if ok else "er"
                self.status_text.insert("end", f"{name:<25}", "in")
                self.status_text.insert("end", f"{status}\n", color)
        else:
            fields = [
                ("Estado",    "Online" if m.get("status") in (True,1) else "Offline"),
                ("IP Interna", ts.get("intranetIp","—")),
                ("IP Externa", ts.get("internetIp","—")),
                ("SW Ver.",    ts.get("curVersion","—")),
                ("RunMode",    ts.get("runMode","—")),
                ("Sync",       (ts.get("lastUpdateTime","—") or "—")[:16]),
            ]
            for k, v in fields:
                self.status_text.insert("end", f"{k:<15} ", "in")
                self.status_text.insert("end", f"{v}\n", "ok")
        self.status_text.config(state="disabled")

    def load_orders(self):
        d = self.api.get_orders()
        if not d or "error" in d:
            self.log("Error cargando pedidos: " + str(d), "er")
            return
        list_ = d.get("content") or d.get("list") or []
        self.orders_data = list_
        self.root.after(0, lambda: self._render_orders(list_))

    def _render_orders(self, list_):
        self.orders_tree.delete(*self.orders_tree.get_children())
        for o in list_:
            det = (o.get("commodityOrderDetailDtos") or [{}])[0]
            succ = det.get("successNum", 0) or 0
            fail = det.get("failureNum", 0) or 0
            state = "Entregado" if succ > 0 else ("Fallo" if fail > 0 else "Pendiente")
            self.orders_tree.insert("", "end", values=(
                (o.get("id","")  or "")[:18],
                det.get("goodsName","—"),
                det.get("goodsTypeName","—"),
                o.get("terminalCode","—"),
                f"${float(o.get('totalAmount',0)):.2f}",
                (o.get("createDate","—") or "—")[:16],
                state,
            ))
        self.orders_count_var.set(f"{len(list_)} pedidos")
        self.log(f"{len(list_)} pedidos cargados", "ok")
        # Actualizar dashboard también
        self._update_dash_orders(list_[:10])

    def _update_dash_orders(self, list_):
        self.dash_tree.delete(*self.dash_tree.get_children())
        for o in list_:
            det = (o.get("commodityOrderDetailDtos") or [{}])[0]
            succ = det.get("successNum", 0) or 0
            fail = det.get("failureNum", 0) or 0
            state = "Entregado" if succ > 0 else ("Fallo" if fail > 0 else "Pendiente")
            self.dash_tree.insert("", "end", values=(
                (o.get("id","") or "")[:18],
                det.get("goodsName","—"),
                o.get("terminalCode","—"),
                f"${float(o.get('totalAmount',0)):.2f}",
                (o.get("createDate","—") or "—")[:16],
                state,
            ))

    def load_products(self):
        d = self.api.get_products()
        if not d or "error" in d:
            self.log("Error cargando productos: " + str(d), "er")
            return
        list_ = d.get("content") or d.get("list") or []
        self.products_data = list_
        self.root.after(0, lambda: self._render_products(list_))

    def _render_products(self, list_):
        self.prod_tree.delete(*self.prod_tree.get_children())
        for p in list_:
            st = "Activo" if p.get("status") in (True, 1) else "Inactivo"
            self.prod_tree.insert("", "end", values=(
                p.get("id","—"),
                p.get("name") or p.get("goodsName","—"),
                f"${p.get('price') or p.get('sellPrice',0)}",
                p.get("goodsTypeName") or p.get("typeName","—"),
                p.get("stock","—"),
                st,
            ))
        self.prod_count_var.set(f"{len(list_)} productos")
        self.log(f"{len(list_)} productos cargados", "ok")

    def load_replenishment(self):
        d = self.api.get_replenishment()
        if not d or "error" in d:
            self.log("Error cargando reabastecimiento: " + str(d), "er")
            return
        list_ = d.get("content") or d.get("list") or []
        self.rep_data = list_
        self.root.after(0, lambda: self._render_rep(list_))

    def _render_rep(self, list_):
        self.rep_tree.delete(*self.rep_tree.get_children())
        for r in list_:
            self.rep_tree.insert("", "end", values=(
                (r.get("createTime","—") or "—")[:16],
                r.get("terminalCode","—"),
                r.get("goodsName") or r.get("productName","—"),
                r.get("count") or r.get("quantity","—"),
                r.get("operName") or r.get("operator","—"),
            ))
        self.rep_count_var.set(f"{len(list_)} registros")
        self.log(f"{len(list_)} reabastecimientos", "ok")

    # ══════════════════════════════════════════
    #  COMANDOS
    # ══════════════════════════════════════════
    def send_cmd(self, ctrl, label, dangerous):
        if not self.selected_machine:
            messagebox.showwarning("Sin máquina", "Selecciona una máquina primero en la pestaña 'Máquinas'.")
            return
        if dangerous:
            name = self.selected_machine.get("name") or self.selected_machine.get("code","")
            if not messagebox.askyesno("Confirmar", f"¿Confirmar '{label}' en la máquina {name}?\n\nEsta acción es inmediata."):
                return
        threading.Thread(target=self._exec_cmd, args=(ctrl, label), daemon=True).start()

    def _exec_cmd(self, ctrl, label):
        code = self.selected_machine.get("code","")
        self.log(f"→ devCommand {{terminalCode:{code}, control:{ctrl}}} [{label}]", "in")
        d = self.api.send_command(code, ctrl)
        if d and isinstance(d, dict) and "error" not in d:
            self.log(f"✓ {label} enviado correctamente", "ok")
            self.root.after(0, lambda: messagebox.showinfo("Éxito", f"✅ {label} ejecutado en {code}"))
        else:
            self.log(f"⚠ {label} — sin confirmación del servidor: {d}", "wr")
            self.root.after(0, lambda: messagebox.showwarning("Enviado", f"Comando enviado (sin confirmación del servidor)"))

    # ══════════════════════════════════════════
    #  LOG
    # ══════════════════════════════════════════
    def log(self, msg, tag="in"):
        def _do():
            self.log_text.config(state="normal")
            ts_str = datetime.now().strftime("%H:%M:%S")
            self.log_text.insert("end", f"[{ts_str}] ", "ts")
            self.log_text.insert("end", msg + "\n", tag)
            self.log_text.see("end")
            self.log_text.config(state="disabled")
        self.root.after(0, _do)

    def clear_log(self):
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.config(state="disabled")

    # ══════════════════════════════════════════
    #  UI HELPERS
    # ══════════════════════════════════════════
    def set_conn(self, ok):
        if ok:
            self.conn_label.config(text="● En línea", fg=ACCENT)
        else:
            self.conn_label.config(text="● Sin conexión", fg=RED)

    # ══════════════════════════════════════════
    #  AUTO-REFRESH
    # ══════════════════════════════════════════
    def start_auto_refresh(self):
        def loop():
            while self.auto_refresh:
                time.sleep(self.refresh_interval)
                if self.auto_refresh:
                    self.refresh_all()
        threading.Thread(target=loop, daemon=True).start()


# ══════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════
if __name__ == "__main__":
    root = tk.Tk()
    app = VMCApp(root)

    def on_close():
        app.auto_refresh = False
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()
